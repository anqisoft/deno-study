import lib from './index.js';

export const png = lib.png;
export const gif = lib.gif;
export const jpeg = lib.jpeg;
export const webp = lib.webp;