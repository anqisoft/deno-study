# Deno 中文手册

这个仓库是 Deno 的非官方中文翻译。

在线查看: https://manual.deno.js.cn/introduction

## 帮助翻译

当提交一个 PR 时，请先确认文档的格式是正确的。通过以下步骤格式化文档:

1. 安装 Deno (https://x.deno.js.cn)
2. 运行 `deno fmt`
