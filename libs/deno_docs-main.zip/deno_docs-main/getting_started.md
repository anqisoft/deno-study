# 快速入门 {#getting-started}

在本章中，我们将讨论：

- [安装 Deno](./getting_started/installation.md)
- [设置环境](./getting_started/setup_your_environment.md)
- [运行 `Hello World` 脚本](./getting_started/first_steps.md)
- [命令行](./getting_started/command_line_interface.md)
- [配置文件](./getting_started/configuration_file.md)
- [了解权限](./getting_started/permissions.md)
- [代码调试](./getting_started/debugging_your_code.md)
