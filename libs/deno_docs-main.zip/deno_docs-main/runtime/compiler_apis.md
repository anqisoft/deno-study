## Compiler APIs {#compiler-apis}

> ℹ️ This section has been moved to
> [TypeScript Runtime APIs](../typescript/runtime.md).
