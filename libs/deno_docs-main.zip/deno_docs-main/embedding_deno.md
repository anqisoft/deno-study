# 嵌入式 Deno {#embedding-deno}

Deno 由多部分组成，其中之一的是 `deno_core`。这是一个 rust crate，可以用作 Rust 应用中的嵌入式 JavaScript
运行时。Deno 基于 `deno_core` 构建。

Deno crate 发布于 [crates.io](https://crates.io/crates/deno_core)。

您可以通过 [docs.rs](https://docs.rs/deno_core) 查阅其 API。

<!-- TODO(lucacasonato): better docs -->
