export interface Message {
  id: string;
  ts: string;
  user: string;
  body: string;
}
