import { start } from "https://raw.githubusercontent.com/lucacasonato/fresh/ae4603c7313fb50f126d3abb31f900ddf7ac611b/server.ts";
import routes from "./routes.gen.ts";

start(routes);
