import { Container } from "~/components";
import { Heading } from "~/ui";

export default function IndexRoute() {
  return (
    <Container>
      <Heading>App 1</Heading>
    </Container>
  );
}
