# Deno Fresh Multiapp Starter

This is a simple proof-of-concept to demonstrate how we can have multiple Fresh
apps in a single repo and share UI components between them.

## Test

**Run App 1**

```
> cd ./app1
> deno task start
```

**Run App 2**

```
> cd ./app2
> deno task start
```
