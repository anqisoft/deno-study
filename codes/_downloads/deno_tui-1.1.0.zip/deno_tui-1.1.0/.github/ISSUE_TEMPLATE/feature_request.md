---
name: Feature request
about: There's something I'd like to be added to project
title: "feat req:"
labels: "feature request"
assignees: ''

---

**What this feature is meaning to achieve** Clear, concise description of what problems would it actually solve.

**Solution** Your take on how it could be implemented.

**Describe alternatives you've considered** What you've already tried to fix problem you described above.
