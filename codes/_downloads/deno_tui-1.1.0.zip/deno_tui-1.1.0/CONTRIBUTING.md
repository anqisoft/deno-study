Tui tries to follow [Deno Style Guide](https://deno.land/manual/contributing/style_guide), so please stick to it when
you want to contribute.
