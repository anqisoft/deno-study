export { assertEquals } from "https://deno.land/std@0.115.1/testing/asserts.ts";
