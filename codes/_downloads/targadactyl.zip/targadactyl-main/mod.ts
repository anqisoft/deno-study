import { TgaLoader } from "./src/tga.ts";

export { TgaLoader };
export default TgaLoader;
export * from "./src/errors.ts";
export * from "./src/tga.ts";
