const raccoons = get("count") * 2 || 2;
console.log("There are now", raccoons, "raccoons 🦝");
set("count", raccoons);
