package com.example.supabase_flutter_quickstart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
