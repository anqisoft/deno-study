export const functionsList = [
  'local: Whatever function is currently served by the CLI',
  'browser-with-cors',
  'select-from-table-with-auth-rls', 
  'send-email-smtp',
]
