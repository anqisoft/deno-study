package com.example.todosupabase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
