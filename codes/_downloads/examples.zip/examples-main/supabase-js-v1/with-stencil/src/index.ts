export { Components, JSX } from './components';
import '@stencil/router';
