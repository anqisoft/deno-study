# Vanilla-js Auth Example

Live Example: [https://auth-vanilla-js.vercel.app/](https://auth-vanilla-js.vercel.app/)

How to sign up and login using supabase and supabase-js using HTML and JavaScript only

<img width="558" alt="image" src="https://user-images.githubusercontent.com/458736/88377414-b6fb4180-cdd1-11ea-8061-103ec4577b7b.png">

### running

`npm run dev` (requires npx to be installed)

if you want to make changes without restarting the server run this in a different terminal window:
`npm run watch`
