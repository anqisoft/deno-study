const Navigation = [
  { name: 'Home', href: '/', current: true },
  { name: 'Jobs', href: '#', current: false },
  { name: 'Developers', href: '#', current: false },
]

export default Navigation
