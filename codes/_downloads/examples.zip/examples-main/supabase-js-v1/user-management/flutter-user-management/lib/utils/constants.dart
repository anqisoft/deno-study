/// TODO: update with your custom SCHEME and HOSTNAME
const myAuthRedirectUri = 'io.supabase.flutterdemo://login-callback';

/// TODO: Add your SUPABASE_URL / SUPABASE_KEY here
const supabaseUrl = 'SUPABASE_URL';
const supabaseAnnonKey = 'SUPABASE_KEY';
