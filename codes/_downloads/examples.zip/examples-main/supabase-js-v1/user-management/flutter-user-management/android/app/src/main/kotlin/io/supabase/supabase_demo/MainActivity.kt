package io.supabase.supabase_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
