import "preact/debug";
export { revive } from "./main.ts";
