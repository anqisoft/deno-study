---
description: |
  This chapter goes over some fundamental concepts of Fresh.
---

This chapter goes over some fundamental concepts of Fresh. It covers the
overarching architecture design of Fresh applications, as well as reference
documentation about the various features of Fresh.
