import { dev } from "./src/dev/mod.ts";
export default dev;
