# fresh website

This is the fresh website source. The fresh website contains:

- a homepage
- a documentation page

### Usage

Start the project:

```
deno task start
```

This will watch the project directory and restart as necessary.
