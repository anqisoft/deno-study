export default function (state: string) {
  document.title = state;
}
