export default function Home(): null {
  throw new Error("boom!");
}
