export const handler = {
  GET() {
    throw Error("it errored!");
  },
};
