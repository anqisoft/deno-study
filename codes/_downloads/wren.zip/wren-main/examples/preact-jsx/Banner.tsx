const Banner = () => {
	return (
		<div>
			Just a banner to show how JSX works in Wren
		</div>
	);
};

export default Banner;
