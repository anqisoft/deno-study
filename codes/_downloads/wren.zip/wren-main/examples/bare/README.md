# Wren Example: Bare

## Run

```
deno task start 
```