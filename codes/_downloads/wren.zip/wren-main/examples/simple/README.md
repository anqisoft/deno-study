# Wren Example: Simple

## Run

```
deno run -A main.ts
```

or using [just](https://github.com/casey/just)

```
just run
```
