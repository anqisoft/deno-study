# fresh project

### Usage

Start the project:

```
deno run -A --watch main.ts
```

After adding, removing, or moving a page in the `pages` directory, run:

```
fresh routes
```
